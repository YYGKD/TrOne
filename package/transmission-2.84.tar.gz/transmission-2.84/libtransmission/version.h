#define PEERID_PREFIX             "-TR2840-"
#define USERAGENT_PREFIX          "2.84"
#define SVN_REVISION              "14307"
#define SVN_REVISION_NUM          14307
#define SHORT_VERSION_STRING      "2.84"
#define LONG_VERSION_STRING       "2.84 (14307)"
#define VERSION_STRING_INFOPLIST  2.84
#define MAJOR_VERSION             2
#define MINOR_VERSION             84
#define TR_STABLE_RELEASE         1
