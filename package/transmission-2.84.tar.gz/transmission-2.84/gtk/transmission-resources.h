#ifndef __RESOURCE_transmission_H__
#define __RESOURCE_transmission_H__

#include <gio/gio.h>

extern GResource *transmission_get_resource (void);
#endif
